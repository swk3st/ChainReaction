export class ChainRec {
    constructor(
       public word1: string,
       public word2: string,
       public word3: string,
       public word4: string,
       public word5: string,
       public word6: string,
       public word7: string,
    ){}
 }
 